import React from 'react';
import { NumberLiteralType } from 'typescript';
import { Vertex, Color } from './Vertex';
function copy<T>(obj: T) : T {
    return JSON.parse(JSON.stringify(obj));
  }


  const getPts = (theta, r, width) => {
    //let a = (r - width) / r;
    return {
        x1: r * Math.cos(theta),
          y1: r * Math.sin(theta),
          x2: r / Math.cos(theta) - Math.tan(theta) * width,
          y2: width,
      }
  }
  
  class SvgPath {
    
    paths: string[] = [];
    offX: number = 0;
    offY: number = 0;

      moveTo(x, y) : void {
        this.paths.push(`M ${x + this.offX} ${y + this.offY}`);
      };
      
      lineTo (x, y) : void {
        this.paths.push(`L ${x + this.offX} ${y + this.offY}`);
      }
      
      curveTo (h1_x, h1_y, h2_x, h2_y, px, py) : void {
        this.paths.push("C " + [h1_x + this.offX, h1_y + this.offY, h2_x + this.offX, h2_y + this.offY, px + this.offX, py + this.offY].join(' '));
      }
      unroll () : string {
        return this.paths.join(' ').replaceAll(/\.\d+ /g, " ");
      }
  }
  
  const makePath = function(theta1, theta2, middle, l, r, width) {
     const p = new SvgPath();
       p.offY = r;
       (() => {
       let { x1, y1, x2, y2} = getPts(theta1, r, width);
       p.moveTo(0, 0);
       p.lineTo(x1, y1);
       p.curveTo(x2, y2, x2, y2, middle, width);
       p.lineTo(middle, 0)
       p.lineTo(0, 0);
       p.lineTo(x1, -y1);
       p.curveTo(x2, -y2, x2, -y2, middle, -width);
       p.lineTo(middle, 0);
       p.lineTo(0, 0);
       })();
       (() => {
      const { x1, y1, x2, y2} = getPts(theta2, r, width);
       p.moveTo(l, 0);
       p.lineTo(l - x1, y1);
       p.curveTo(l - x2, y2, l - x2, y2, middle, width);
       p.lineTo(middle, 0);
       p.lineTo(l, 0);
       p.lineTo(l - x1, -y1);
       p.curveTo(l - x2, -y2, l - x2, -y2, middle, -width);
       p.lineTo(middle, 0);
       p.lineTo(l, 0);
       })();
      
       
       return `path(nonzero, "${p.unroll()}")`;
  }

type BackgroundEvent = Record<string, (color1: string, color2?: string) => void>;

class ColorError extends Error {
  constructor(name, mode) {
    super(`Attempted to call ${name} while edge was in stage ${mode}`);
    this.name = "ColorError";
  }
}
enum BackgroundMode {
  Solid,
  Gradient
}
interface EdgeProps {
    p1: Vertex,
    p2: Vertex,
    color1: string,
    color2: string,
    //up: {
      //hookSetColor: (f: (color: string) => void) => void;
      //hookColorFunctions: (fs: Record<string, Function>) => void;
    //}
    /*events: Record<string, BackgroundEvent>*/
  }

  interface EdgeState {
    clipState: number;
    color1: string,
    color2: string,
    backgroundMode: BackgroundMode,
  }
  
  class Edge extends React.Component<EdgeProps, EdgeState> {

    private clipStates: string[] = [];
    private w: number;
    private h: number;
    private length: number;
    private left: number;
    private top: number;
    private angle: number;

    static default(p1: Vertex, p2: Vertex) {
      return new Edge({
        p1, p2,
        backgroundMode: BackgroundMode.Solid,
        color1: Color.Default,
        color2: Color.Default,
      });
      
    }


    constructor (props) {
      super(props);
      //copy props to state
      //this.state = props;//copy<EdgeProps>(props);
      this.state = {
        clipState: 0,
        color1: props.color1,
        color2: props.color2,
        backgroundMode: BackgroundMode.Solid,
      }
      const colorFunctions: Record<string, Function> = { };
      this.colorRef = React.createRef();
      const {p1, p2} = props;

      this.w = p2.props.p.x - p1.props.p.x;
      this.h = p2.props.p.y - p1.props.p.y;
      this.length = Math.hypot(this.w, this.h);
      this.left = p1.props.p.x;//Math.min(x1, x2);
      this.top = p1.props.p.y;//Math.min(y1, y2);
      this.angle = Math.atan2(this.h, this.w) * 180 / Math.PI;// * Math.sign(h);

      const l  = this.length;
      this.clipStates = [
        makePath(Math.PI / 6, Math.PI / 6, l * 0.5, l, 30, 3),
        makePath(Math.PI * 2 / 5, Math.PI / 6, l * 0.8, l, 30, 5),
        makePath(Math.PI / 6, Math.PI * 2 / 5, l * 0.3, l, 30, 5),
        makePath(Math.PI * 2 / 5, Math.PI * 2 / 5, l * 0.5, l, 30, 10),
      ]
    }

    componentDidMount() {
      console.log("mounted");
      this.setClipState(0);
    }

    colorRef;
    getIndex1() : number {
      return this.props.p1.state.index1;
    }

    getIndex2(): number {
      return this.props.p2.state.index1;
    }

    styleInstantly(el: HTMLElement, f: Function) {
      // https://stackoverflow.com/questions/11131875/what-is-the-cleanest-way-to-disable-css-transition-effects-temporarily
      el.classList.add('notransition');
      f();
      let x = el.offsetHeight;
      el.classList.remove('notransition');
    }
      /*Solid(1) fades to Solid(2);
      Solid(1) swipes to Solid(2)
      Solid(1) reverse swipes to Solid(2);
      Solid(x) fades to Gradient(x, y)
      Solid(y) fades to Gradient(x, y)
      Solid(x) swipes to Gradient(x y)
      Solid(y) swipes to Gradient(x, y)
      Gradient(x, y) fades to Solid(x)
      Gradient(x, y) fades to Solid(y)
      Gradient(x, y) swipes to Solid(x)
      Gradient(x, y) swipes to Gradient(x) 
      Gradient(x, y) fades to Gradient(z, y)
      Gradient(x, y) fades to Gradient(x, z);*/
    fadeToSolid(color1: string) {
      
    }
    
    setClipState(clipState: number) {
      const lineDiv = this.colorRef.current.querySelector('.edge_inner');
      lineDiv.style.clipPath = this.clipStates[clipState];
      this.setState({clipState})
    }

    makeGradientString(color1: string, color2: string) : string {
      return `linear-gradient(90deg, ${color2} 0%, ${color2} 33%, ${color1} 67%, ${color1} 100%)`;
    }

    reset() {
      this.fadeToSolid(Color.Default);
      this.setState({
        color1: Color.Default,
        color2: Color.Default,
        backgroundMode: BackgroundMode.Solid,
      })
    }

    sweepForward(color1: string, color2: string) : void {
      if (this.state.backgroundMode == BackgroundMode.Gradient) {
        throw new ColorError("moveForward", this.state.backgroundMode);
      }
      const gradient = this.makeGradientString(color1, color2);
      const newBG = {
        backgroundImage: gradient,
      }
      const lineDiv = this.colorRef.current.querySelector('.edge_inner');
      if ( !lineDiv ) return;

      
      this.styleInstantly(lineDiv, () => {
        lineDiv.style.backgroundImage = gradient;
        lineDiv.style.backgroundPositionX = "100%";
      });
      this.setClipState(1);
      lineDiv.style.backgroundPositionX = "66%";
      const onComplete = () => {
        this.styleInstantly(lineDiv, () => {
          lineDiv.style.backgroundImage = color2;
          lineDiv.style.backgroundPositionX = "0%";
        });

        this.setState({backgroundMode: BackgroundMode.Solid, color1: color2});
      }
      window.setTimeout(() => {
        this.setClipState(2);
        lineDiv.style.backgroundPositionX = "0%";
        window.setTimeout(() => {
          this.setClipState(0);
          //window.setTimeout(() => {
           // this.setClipState(0);
          //}, 200);
          window.setTimeout(onComplete, 1000);
        }, 300);
      }, 300);

      
      
      
      
    }
  
    render() {
      // Get and apply position values
      const {top, left, length, angle} = this;
      const styleMain = {
        top, left, width: `${length}px`,
        transform: `rotate(${angle}deg)`,
      }

      let styleInner;
      const color1 = this.state.color1;
      const color2 = this.state.color2;
      if (this.state.backgroundMode == BackgroundMode.Solid) {
        // most of the time, it seems
        styleInner = { backgroundColor: this.state.color1 };
      } else if (this.state.backgroundMode == BackgroundMode.Gradient) {
        styleInner = { backgroundImage: `linear-gradient(90deg, ${color1} 0%, ${color1})33%, {color2}67%, ${color2}100%`}
      }

      styleInner.clipPath = this.clipStates[this.state.clipState];
      return (
        <div key={"vertex" + this.props.p1.state.index1 + "/" + this.props.p2.state.index1}  ref={this.colorRef}  className="edge" style={styleMain}>
          <div className="edge_inner" style={styleInner}> 
            <div className="edge_arrow"></div>
          </div>
        </div>
      )
    }
  
  
  }

  export {
    Edge,
    BackgroundMode
  }

