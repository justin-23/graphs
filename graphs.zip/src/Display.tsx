import React from 'react';

import Board from './Board';



class Display extends React.Component {
    render() {
        return (
            <div></div>
        )
    }
}

export default Display;