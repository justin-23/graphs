import { EEXIST } from 'constants';
import { Edge } from './Edge';
import Color from './Color';
import { AnimationType, StepEntry, Step} from './Step';
interface GraphData {
    edgeInfo: number[][];
    size: number;
}
class Graph implements GraphData {

    size: number;
    edgeInfo: number[][];
    constructor(edges: Edge[][]) {
        this.edgeInfo = edges.map((row: Edge[]) => {
            return row.map((e: Edge) => {
                return e.getIndex2();
            });
        })
        this.size = edges.length;
    }

    runDepthFirstSearch(start: number, color: string) : Step[]{

        if ((!this.edgeInfo[start]) || start < 0 || start > this.size) {
            throw Error("fill in");
        }

        const seen: number[] = [start];
        const stack: number[] = [start];
        let next;
        let steps: Step[] = [];

        let doSearch = (from: number)  => {
            this.edgeInfo[from].forEach((to: number) => {
                if (seen.indexOf(to) < 0) {
                    seen.push(to);
                    let s: Step =  {
                        steps: [
                            {
                                index1: from,
                                index2: to,
                                color1: color,
                                color2: Color.Red,
                                animationType: AnimationType.SweepForward,
                            }
                        ]
                    };
                    steps.push(s);
                    doSearch(to);
                }
            })
        }    

        doSearch(start);
        return steps;
    }
}
export default Graph;