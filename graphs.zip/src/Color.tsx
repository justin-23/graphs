enum Color {
    Default = "#b8b8be",
    Black = "#030b1f",
    Red = "#16d867",
    Blue = "#155cc7",
    Green = "#16d867",  
  }

  
export default Color;