import { timeStamp } from 'console';
import React from 'react';

interface GUIProps {up: {set: Function, run: Function}} 
interface GUIState {mode: string}

class GUI extends React.Component<GUIProps, GUIState> {
  constructor (props: any) { 
    super(props);
    
    this.state = {
      mode: "EDIT"
    }    
  }

  onclick_editmode = (e) => {
    this.props.up.set('editmode', e.target.textContent.toUpperCase())
  }

  onclick_mode = e => {
    this.setState({mode: e.target.textContent.toUpperCase()});
    this.props.up.set('mode', e.target.textContent.toUpperCase());
  }

  onclick_runmode = e => {
    this.props.up.set('testmode', e.target.textContent.toUpperCase());
  }

  onclick_run = (e) => {
    this.props.up.run();
  }



  render() {
    let guiEditStyle = {
      
    }
    return (
      <div className="guiOuter">
        <div className={"guiCategory guiEdit " + (this.state.mode == "EDIT" ? "" : "disable")}>
          <div className="clickElement" onClick={((e) => this.onclick_editmode(e))}>New</div>
          <div className="clickElement" onClick={this.onclick_editmode}>Delete</div>
          <div className="clickElement" onClick={this.onclick_editmode}>Connect</div>
          <div className="clickElement" onClick={this.onclick_editmode}>Set Start</div>
        </div>
        <div className="guiCategory guiMode">
          <div className="clickElement clickMedium" onClick={this.onclick_mode}>Edit</div>
          <div className="clickElement clickMedium" onClick={this.onclick_mode}>Test</div>
        </div>
        <div className={"guiCategory guiTest " + (this.state.mode == "TEST" ? "" : "disable")}>
          <div className="clickElement" onClick={this.onclick_runmode}>Mode1</div>
          <div className="clickElement" onClick={this.onclick_runmode}>Mode2</div>
          <div className="clickElement clickImportant" onClick={(e) => this.onclick_run(e)}>Run</div>
        </div>
      </div>
    )
  }
}

export default GUI;