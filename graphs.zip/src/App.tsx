import React from 'react';
import logo from './logo.svg';
import './App.css';
import './Display.tsx';
import Board from './Board';
import { getDefaultCompilerOptions } from 'typescript';


function App() {
  return (
    <div className="App">
         <Board />
    </div>
  );
}



export default App;
