import React, { ReactElement } from 'react';
import { Edge, BackgroundMode } from './Edge';
import { Vertex } from './Vertex';
import GUI from './GUI';
import Graph from './Graph';
import { AnimationType, StepEntry, Step} from './Step';
import Color from './Color';
import VertexColor from './VertexColor';
import { stringify } from 'querystring';
import { getJSDocReadonlyTag, readBuilderProgram } from 'typescript';


const DELAY_TIME = 400;
let BOARD_SIZE = 1000;
const VERTEX_RADIUS = 50;
const PADDING_SIZE = 5;





function copy<T>(obj: T) : T {
  return JSON.parse(JSON.stringify(obj));
}



declare global {
  interface Promise<T> {
    delay(t: number): any;
  }
}
// https://stackoverflow.com/questions/39538473/using-settimeout-on-promise-chain
function delay(t, v) {
  return new Promise(function(resolve) { 
      setTimeout(resolve.bind(null, v), t)
  });
}

Promise.prototype.delay = function(t) {
  return this.then(function(v) {
      return delay(t, v);
  });
}

const getRelativeCoords = function(e: React.MouseEvent){
    // source: https://stackoverflow.com/questions/3234256/find-mouse-position-relative-to-element
    const el = document.querySelector('.board') as Element;
    
    
    const event = e.nativeEvent;
    const target = event.target as HTMLElement;


    const rect = target.getBoundingClientRect();

    const position = {
      x: event.pageX,
      y: event.pageY,
    };
  
    const offset = {
      left: rect.x,
      top: rect.y
    };
  
    return { 
      x: event.clientX- rect.x,
      y: event.clientY - rect.y,
    }; 
  
}

interface BoardSettings {
  mode: string,
  editmode: string,
  testmode: string,
}

interface BoardState {
  vertices: Vertex[];
  edges: Edge[][];
  start: number;
  settings: BoardSettings;
}

interface BoardProps { };

class Board extends React.Component<BoardProps, BoardState> {

  static interpretMouseEvent = function(e: React.MouseEvent) {
    const {x, y} = getRelativeCoords(e);
    // Get coordinates reative to the board
    const index = e.target;
    // maybe delete i think
    const id = e["vertexId"];
    // get the ID of the clicked vertex.
    let validLocation = Board.isValidLocation(x, y);
    // Is within bounds?
    let hitSpacer = Boolean(e["hitSpacer"]);
    // did we hit a "spacer" (to provide room. no overlap)
    let hitVertex = id !== undefined;
    // duh
    return {
      x, y, hitSpacer, hitVertex, id, validLocation,
    }
  }
  constructor(props: any) {
    super(props);

    ["addVertex", "deleteVertex", "updateSetting", "addEdge", "deleteEdge", "run"].forEach((fnName: string) => {
      this[fnName] = this[fnName].bind(this);
    }); // Bind all functions that are passed to child components to 'Board' this

    this.state = {
      vertices: [],
      edges: [],
      settings: {
        mode: "EDIT",
        editmode: "NEW",
        testmode: "TEST1",
      },
      start: 0,
    };

    this.mouseDownVertexId = -1;
    
  }
  settings; mouseDownVertexId = -1;

  /// Retreives and passes settings up to be set on the board state.
  updateSetting (key: string, value: string) {
    const newSettings = copy<BoardSettings>(this.state.settings);
    // newSettings is now origional state plus edit
    Object.assign(newSettings, {[key]: value});

    this.setState({settings: newSettings}, () => {
      console.log(`Update set on prop ${key}: ${this.state.settings[key]}`)
    });
    
  }

  componentDidMount() {
    BOARD_SIZE = window.innerWidth;
  }

  static isValidLocation(x: number, y: number) {
    let outBox = [x, y].some(dim => dim < (PADDING_SIZE + VERTEX_RADIUS) || dim > (BOARD_SIZE - PADDING_SIZE - VERTEX_RADIUS));
    return !(outBox);
  }

  setStart(v: number) : void {
    const prevStart = this.state.start;
    const prevStartVertex = this.getVertex(prevStart);
    if (prevStartVertex) prevStartVertex.setState({isStart: false});
    this.setState({start: v});
    this.getVertex(v).setStart();/*setState({isStart: true}, function() {
      console.log("Set state");
    });*/
  }
  onmousedown(event: React.MouseEvent) : void {

    const {x, y, hitSpacer, hitVertex, id, validLocation} = Board.interpretMouseEvent(event);


    const mode: string = this.state.settings["mode"];
    if (mode == 'EDIT') {
        switch (this.state.settings["editmode"]) {
            case 'NEW':
              if (validLocation && !hitSpacer) {
                const v = this.addVertex(x, y); 
                // v.fadeTo("blue");
              }
              break;
            case 'DELETE':
              if (hitVertex) this.deleteVertex(id); 
              break;
            case 'CONNECT':
              if (hitVertex) {
                this.mouseDownVertexId = id;
              }
              break;
            case 'SET START':
              if (hitVertex) {
                this.setStart(id);
              } break;
            default: break;
          }
    } else if (mode == 'TEST') {
        console.log("Edges", this.state.edges);
        const colors = ["red", "yellow", "blue", "grey", "green", "black"];
        switch(this.state.settings.testmode) {
          case 'MODE1':
           /* this.state.edges.flat().filter(Boolean).forEach((edge: Edge) => {

              const color1 = colors[Math.floor(Math.random() * 6)];
              const color2 = colors[Math.floor(Math.random() * 6)];
              //console.log("Setting", color1, edge.state.index1, edge.state.index2);
              console.log("changing color...");
            
              if (edge != null && edge.sweepForward) //edge.sweepForward(color1, color2);
              this.animateSweep(0, 1);
          });*/
          this.doSweep(0, 1, Color.Red, Color.Blue);
          break;

          case 'MODE2':
            this.state.vertices[0].fadeTo("blue");
            console.log("changed color 1");
            break;
         
            
        }
         
    } else {
        console.log("unknown board mode");
    }
    
  }

  getAllVertices() {
    return [...this.state.vertices];
  }
  getAllEdges() {
    return [...this.state.edges.flat().filter(Boolean)];
  }
  private getVertex(index1: number) {
    return this.state.vertices[index1];
  }

  private getEdge(index1: number, index2: number) {
    return this.state.edges[index1][index2];
  }
  onmouseup(event: React.MouseEvent) {

    const {x, y, hitSpacer, hitVertex, id, validLocation} = Board.interpretMouseEvent(event);
    const mode: string = this.state.settings["mode"];
    if (mode == 'EDIT') {
        switch (this.state.settings["editmode"]) {
        case 'CONNECT':
            if (hitVertex) {
            const from = this.mouseDownVertexId;
            const to = id;

            this.addEdge(from, to);
            break;
            }
        }
    } else if (mode == 'TEST') {

    }
  } 
  // adds a new vertex. updates vertexs and edges.
  addVertex(x: number, y: number) : Vertex {
   
    const position = this.state.vertices.length;
    //let vertices = copy<Vertex[]>(this.state.vertices);
    let vertices = this.state.vertices;
    let edges = this.state.edges;//copy<Edge[][]>(this.state.edges);

    /*vertices = [...vertices, {
      index1: position, color1: Color.Default, background: {}
    }];*/
    const v = Vertex.default(position, x, y);
    vertices.push(v);
    edges.push([]);
    
    this.setState({vertices, edges})

    return v;
  }

  deleteVertex(index: number) {
    const vertices = this.state.vertices; //copy<Vertex[]>(this.state.vertices)// get the current vertexs
    const edges = this.state.edges; //copy<Edge[][]>(this.state.edges);
    vertices.splice(index, 1); // Remove the proper index
    edges.splice(index, 1);
    const length = vertices.length;
    for (let i = index; i <  length; i++) {
      vertices[i].decrementIndex()
      edges[i] = edges[i].map((edge: Edge, j) => (edge.getIndex1() >= index) ? edges[i][j+1] : edge);
      //edges[i].slice(index).forEach(edge => edge.index2)
    }
    this.setState({vertices, edges}); // set the new ones 
  }

  addEdge(index1: number, index2: number) {
    const edges = this.state.edges;//copy<Edge[][]>(this.state.edges);
    const row = edges[index1];
    const el = row[index2];
    if (el !== undefined) return;
    row[index2] = Edge.default(this.getVertex(index1), this.getVertex(index2));
    this.setState({edges}, () => {
      console.log("new edges area: ", this.state.edges)
    });
  }

  deleteEdge(index1: number, index2: number) {

  }
  renderVertices() {
    return this.state.vertices.map
    (
      (vertex: Vertex) => vertex.render()
    );
  }
  
  renderEdges() {
    return this.state.edges.map
    (
      (tos: Edge[]) => tos.map((edge: Edge) => edge.render())
    ).flat()
  }

  animateStep(step: Step) {
    return Promise.all<void>(step.steps.map((entry: StepEntry) => {
      return this.animateStepEntry(entry);
    }));
  }
  animateStepEntry(entry: StepEntry) {
    switch (entry.animationType) {
      case AnimationType.SweepForward:
        return new Promise<void>((resolve, reject) => {
          this.doSweep(entry.index1, entry.index2, entry.color1, entry.color2);
          resolve();//setTimeout(() => resolve(), 400);
        });
      default:
        return Promise.resolve();
    }
  }

  animateSteps(steps: Step[]) {
    //steps.reduceRight((current, step) => current.then(this.animateStep(step)), Promise.resolve())
    steps.reduce((curr, step) => curr.delay(DELAY_TIME * 3 / 2).then(() => this.animateStep(step)), Promise.resolve())
  }
  reset() {
    this.getAllEdges().forEach(edge => edge.reset());
    this.getAllVertices().forEach(vertex => vertex.reset());
  }
  run() {
    this.reset();
    const graph = new Graph(this.state.edges);
    console.log(graph);
    
    let steps: Step[] = graph.runDepthFirstSearch(this.state.start, Color.Black);

    this.animateSteps(steps);
  
  }
  

  doSweep(index1: number, index2: number, color1: string, color2: string) {
    const v1 = this.getVertex(index1);
    const v2 = this.getVertex(index2);
    console.log("sweep vertices", {v1, v2})
    const edge = this.getEdge(index1, index2);

    //const color2 = v2.state.color;
    //const color1 = v1.state.color;

    this.animateSweep(edge, v1.state.color, color1);
    Promise.resolve().delay(250).then(resolve => v2.fadeTo(color1));
  }
  animateSweep(edge: Edge, color1: string, color2: string) {

    edge.sweepForward(color1, color2);
  }

  render() {
    return (
    
    <div className="board">
      <GUI up={{set: this.updateSetting, run: this.run}} />
      <div className = "boardDisplay"  
        onMouseDown={(e: React.MouseEvent) => this.onmousedown(e)}
        onMouseUp={(e: React.MouseEvent) => this.onmouseup(e)}
      >
        { [...this.renderVertices(), ...this.renderEdges()] }
      </div>
    </div>
      )
  }
}

export default Board;